from kyt import *

#LOCK ssh
@bot.on(events.CallbackQuery(data=b'lock-ssh'))
async def lock_ssh(event):
	async def lock_ssh_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-lock'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Locked**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lock_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#UNLOCK ssh
@bot.on(events.CallbackQuery(data=b'unlock-ssh'))
async def unlock_ssh(event):
	async def unlock_ssh_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-unlock'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Unlock**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlock_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#DELETESSH
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**Username To Be Deleted:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			cmd = f'printf "%s\n" "{user}" | bot-del-ssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Successfully Deleted**")
		else:
			await event.respond(f"**Successfully Deleted** `{user}`")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#RENEWSSH
@bot.on(events.CallbackQuery(data=b'recov-ssh'))
async def recov_ssh(event):
	async def recov_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**Username To Be RENEW:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Days:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
			cmd = f'printf "%s\n" "{user}" "{pw}" | bot-renew-ssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"`{user}` ** TIDAK DITEMUKAN! **")
		else:
			await event.respond(f"""
```
{a}
```
**RENEW SSH**
**» 🤖@JURAGAN_HC**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await recov_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
        
#LIMITSSH
@bot.on(events.CallbackQuery(data=b'limit-ssh'))
async def limit_ssh(event):
	async def limit_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**Username :**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Limit-IP :**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
			cmd = f'printf "%s\n" "{user}" "{pw}" | bot-ganti-ip-ssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"`{user}` ** TIDAK DITEMUKAN! **")
		else:
			await event.respond(f"""
```
{a}
```
**GANTI IP SSH**
**» 🤖@JURAGAN_HC**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await limit_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Password:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as pw1:
			await event.respond("**Limit-ip:**")
			pw1 = pw1.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw1 = (await pw1).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Expaired:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" "{pw}" "{pw1}" "{exp}" | bot-add-ssh'
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond(f"**User** `{user}` **Successfully Created**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ 𝚜𝚜𝚑 𝚘𝚟𝚙𝚗 𝚊𝚌𝚌𝚘𝚞𝚗𝚝 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» 𝚄𝚂𝙴𝚁𝙽𝙰𝙼𝙴         :** `{user.strip()}`
**» 𝙿𝙰𝚂𝚂𝚆𝙾𝚁𝙳         :** `{pw.strip()}`
**━━━━━━━━━━━━━━━━━**
**» 𝙷𝙾𝚂𝚃             :** `{DOMAIN}`
**» 𝙷𝙾𝚂𝚃 𝚂𝙻𝙾𝚆𝙳𝙽𝚂     :** `{HOST}`
**» 𝙿𝚄𝙱 𝙺𝙴𝚈          :** `{PUB}`
**» 𝚙𝚘𝚛𝚝 𝚘𝚙𝚎𝚗𝚜𝚜𝚑     :** `443, 80, 22`
**» 𝚙𝚘𝚛𝚝 𝚍𝚗𝚜         :** `443, 53 ,22`
**» 𝙿𝙾𝚁𝚃 𝙳𝚁𝙾𝙿𝙱𝙴𝙰𝚁    :** `443, 109`
**» 𝚙𝚘𝚛𝚝 𝚍𝚛𝚘𝚙𝚋𝚎𝚊𝚛 𝚠𝚜 :** `443, 109`
**» 𝚙𝚘𝚛𝚝 𝚜𝚜𝚑 𝚠𝚜      :** `80, 8080, 8081-9999 `
**» 𝚙𝚘𝚛𝚝 𝚜𝚜𝚑 𝚜𝚜𝚕 𝚠𝚜  :** `443`
**» 𝚙𝚘𝚛𝚝 𝚜𝚜𝚕/𝚝𝚕𝚜     :** `222-1000`
**» 𝚙𝚘𝚛𝚝 𝚘𝚟𝚙𝚗 𝚠𝚜 𝚜𝚜𝚕 :** `443`
**» 𝚙𝚘𝚛𝚝 𝚘𝚟𝚙𝚗 𝚜𝚜𝚕    :** `443`
**» 𝚙𝚘𝚛𝚝 𝚘𝚟𝚙𝚗 𝚝𝚌𝚙    :** `443, 1194`
**» 𝚙𝚘𝚛𝚝 𝚘𝚟𝚙𝚗 𝚞𝚍𝚙    :** `2200`
**» 𝙿𝚁𝙾𝚇𝚈 𝚂𝚀𝚄𝙸𝙳     :** `3128`
**» 𝚋𝚊𝚍𝚟𝚙𝚗 𝚞𝚍𝚙       :** `7100, 7300, 7300`
**━━━━━━━━━━━━━━━━━**
**» 𝚙𝚊𝚢𝚕𝚘𝚊𝚍 𝚠𝚜       :** `GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━**
**» 𝚘𝚙𝚎𝚗𝚟𝚙𝚗 𝚠𝚜 𝚜𝚜𝚕   :** `https://{DOMAIN}:81/ws-ssl.ovpn`
**» 𝚘𝚙𝚎𝚗𝚟𝚙𝚗 𝚜𝚜𝚕      :** `https://{DOMAIN}:81/ssl.ovpn`
**» 𝚘𝚙𝚎𝚗𝚟𝚙𝚗 𝚝𝚌𝚙      :** `https://{DOMAIN}:81/tcp.ovpn`
**» 𝚘𝚙𝚎𝚗𝚟𝚙𝚗 𝚞𝚍𝚙    :** `https://{DOMAIN}:81/udp.ovpn`
**━━━━━━━━━━━━━━━━━**
**» 𝚂𝙰𝚅𝙴 𝙻𝙸𝙽𝙺 𝙰𝙲𝙲𝙾𝚄𝙽𝚃:** `https://{DOMAIN}:81/ssh-{user.strip()}.txt`
**» 𝙴𝚇𝙿𝙸𝚁𝙴𝙳 𝚄𝙽𝚃𝙸𝙻:** `{later}`
**━━━━━━━━━━━━━━━━━**
**» 𝚜𝚜𝚑 𝚠𝚜         :** ``{DOMAIN}:80@{user.strip()}:{pw.strip()}``
**» 𝚜𝚜𝚑 𝚜𝚜𝚕          :** ``{DOMAIN}:443@{user.strip()}:{pw.strip()}``
**» 𝚜𝚜𝚑 𝚞𝚍𝚙         :** ``{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}``
**━━━━━━━━━━━━━━━━━**
``
◇━━━━━━━━━━━━━━━━━◇
*_PEMBELIAN BERHASIL_*
◇━━━━━━━━━━━━━━━━━◇
-» PRODUK : SSH
-» REGION : {city.strip()}
-» REQ CONFIG : 
-» REQ NAMA : {user.strip()}
-» DEVICE : 2 IP
-» HARGA : 
-» AKTIF : {exp} HARI
-» TGL EXP : {later}
◇━━━━━━━━━━━━━━━━━◇
``
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#RECOSSH
@bot.on(events.CallbackQuery(data=b'reco-ssh'))
async def reco_ssh(event):
	async def reco_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" | bot-user-ssh'
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond(f"**User** `{user}` **Successfully Checked**")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await reco_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'bot-member-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
**Show All SSH User**
**»🤖@JURAGAN_HC**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)



@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Minutes:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-trial-ssh'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Trial Successfully Created**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ SSH OVPN ACCOUNT 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» 𝚄𝚂𝙴𝚁𝙽𝙰𝙼𝙴         :** `{user.strip()}`
**» 𝙿𝙰𝚂𝚂𝚆𝙾𝚁𝙳         :** `{pw.strip()}`
**━━━━━━━━━━━━━━━━━**
**» 𝙷𝙾𝚂𝚃             :** `{DOMAIN}`
**» 𝙷𝙾𝚂𝚃 𝚂𝙻𝙾𝚆𝙳𝙽𝚂     :** `{HOST}`
**» 𝙿𝚄𝙱 𝙺𝙴𝚈          :** `{PUB}`
**» 𝚙𝚘𝚛𝚝 𝚘𝚙𝚎𝚗𝚜𝚜𝚑     :** `443, 80, 22`
**» 𝚙𝚘𝚛𝚝 𝚍𝚗𝚜         :** `443, 53 ,22`
**» 𝙿𝙾𝚁𝚃 𝙳𝚁𝙾𝙿𝙱𝙴𝙰𝚁    :** `443, 109`
**» 𝚙𝚘𝚛𝚝 𝚍𝚛𝚘𝚙𝚋𝚎𝚊𝚛 𝚠𝚜 :** `443, 109`
**» 𝚙𝚘𝚛𝚝 𝚜𝚜𝚑 𝚠𝚜      :** `80, 8080, 8081-9999 `
**» 𝚙𝚘𝚛𝚝 𝚜𝚜𝚑 𝚜𝚜𝚕 𝚠𝚜 :** `443`
**» 𝚙𝚘𝚛𝚝 𝚜𝚜𝚕/𝚝𝚕𝚜     :** `222-1000`
**» 𝚙𝚘𝚛𝚝 𝚘𝚟𝚙𝚗 𝚠𝚜 𝚜𝚜𝚕 :** `443`
**» 𝚙𝚘𝚛𝚝 𝚘𝚟𝚙𝚗 𝚜𝚜𝚕    :** `443`
**» 𝚙𝚘𝚛𝚝 𝚘𝚟𝚙𝚗 𝚝𝚌𝚙   :** `443, 1194`
**» 𝚙𝚘𝚛𝚝 𝚘𝚟𝚙𝚗 𝚞𝚍𝚙    :** `2200`
**» 𝙿𝚁𝙾𝚇𝚈 𝚂𝚀𝚄𝙸𝙳     :** `3128`
**» 𝚋𝚊𝚍𝚟𝚙𝚗 𝚞𝚍𝚙      :** `7100, 7300, 7300`
**━━━━━━━━━━━━━━━━━**
**» 𝚜𝚜𝚑 𝚠𝚜        :** ``{DOMAIN}:80@{user.strip()}:{pw.strip()}``
**» 𝚜𝚜𝚑 𝚜𝚜𝚕          :** ``{DOMAIN}:443@{user.strip()}:{pw.strip()}``
**» 𝚜𝚜𝚑 𝚞𝚍𝚙          :** ``{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}``
**━━━━━━━━━━━━━━━━━**
**» 𝚙𝚊𝚢𝚕𝚘𝚊𝚍 𝚠𝚜       :** `GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━**
**» 𝚘𝚙𝚎𝚗𝚟𝚙𝚗 𝚠𝚜 𝚜𝚜𝚕   :** `https://{DOMAIN}:81/ws-ssl.ovpn`
**» 𝚘𝚙𝚎𝚗𝚟𝚙𝚗 𝚜𝚜𝚕      :** `https://{DOMAIN}:81/ssl.ovpn`
**» 𝚘𝚙𝚎𝚗𝚟𝚙𝚗 𝚝𝚌𝚙      :** `https://{DOMAIN}:81/tcp.ovpn`
**» 𝚘𝚙𝚎𝚗𝚟𝚙𝚗 𝚞𝚍𝚙      :** `https://{DOMAIN}:81/udp.ovpn`
**━━━━━━━━━━━━━━━━━**
**» 𝚂𝙰𝚅𝙴 𝙻𝙸𝙽𝙺 𝙰𝙲𝙲𝙾𝚄𝙽𝚃:** `https://{DOMAIN}:81/ssh-{user.strip()}.txt`
**» 𝙴𝚇𝙿𝙸𝚁𝙴𝙳 𝚄𝙽𝚃𝙸𝙻:** {today}
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		cmd = 'bot-cek-login-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**𝚜𝚑𝚘𝚠𝚜 𝚕𝚘𝚐𝚐𝚎𝚍 𝚒𝚗 𝚞𝚜𝚎𝚛𝚜 𝚜𝚜𝚑 𝚘𝚟𝚙𝚗**
**» 🤖@JURAGAN_HC**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)


@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline(" 𝚝𝚛𝚒𝚊𝚕 𝚜𝚜𝚑 ","trial-ssh"),
Button.inline(" 𝚌𝚛𝚎𝚊𝚝𝚎 𝚜𝚜𝚑 ","create-ssh")],
[Button.inline(" 𝚛𝚎𝚗𝚎𝚠 𝚜𝚜𝚑 ","recov-ssh"),
Button.inline(" 𝚍𝚎𝚝𝚊𝚒𝚕 𝚜𝚜𝚑 ","reco-ssh")],
[Button.inline(" 𝚍𝚎𝚕𝚎𝚝𝚎 𝚜𝚜𝚑 ","delete-ssh"),
Button.inline(" 𝚌𝚑𝚎𝚌𝚔 𝚕𝚘𝚐𝚒𝚗 𝚜𝚜𝚑 ","login-ssh")],
[Button.inline(" 𝚕𝚘𝚌𝚔 𝚜𝚜𝚑 ","lock-ssh"),
Button.inline(" 𝚞𝚗𝚕𝚘𝚌𝚔 𝚜𝚜𝚑 ","unlock-ssh")],
[Button.inline(" 𝚜𝚑𝚘𝚠 𝚊𝚕𝚕 𝚞𝚜𝚎𝚛 𝚜𝚜𝚑 ","show-ssh"),
Button.inline(" 𝚐𝚊𝚗𝚝𝚒 𝚕𝚒𝚖𝚒𝚝 𝚒𝚙 ","limit-ssh")],
[Button.inline("‹ 𝙼𝙰𝙸𝙽 𝙼𝙴𝙽𝚄 ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**✰ 𝚜𝚜𝚑 𝚘𝚟𝚙𝚗 𝚖𝚊𝚗𝚊𝚐𝚎𝚛 ✰**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Service:** `SSH OVPN`
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{z["isp"]}`
🔰 **» Country:** `{z["country"]}`
🤖 **» @JURAGAN_HC**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)
