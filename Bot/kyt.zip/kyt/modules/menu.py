from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" 𝚜𝚜𝚑 𝚘𝚟𝚙𝚗 𝚖𝚊𝚗𝚊𝚐𝚎𝚛 ","ssh")],
[Button.inline(" 𝚟𝚖𝚎𝚜𝚜 𝚖𝚊𝚗𝚊𝚐𝚎𝚛 ","vmess"),
Button.inline(" 𝚟𝚕𝚎𝚜𝚜 𝚖𝚊𝚗𝚊𝚐𝚎𝚛 ","vless")],
[Button.inline(" 𝚝𝚛𝚘𝚓𝚊𝚗 𝚖𝚊𝚗𝚊𝚐𝚎𝚛 ","trojan"),
Button.inline(" 𝚜𝚑𝚍𝚠𝚜𝚔 𝚖𝚊𝚗𝚊𝚐𝚎𝚛","shadowsocks")],
[Button.inline(" 𝚌𝚑𝚎𝚌𝚔 𝚟𝚙𝚜 𝚒𝚗𝚏𝚘 ","info"),
Button.inline(" 𝚘𝚝𝚑𝚎𝚛 𝚜𝚎𝚝𝚝𝚒𝚗𝚐 ","setting")],
[Button.inline(" ‹ 𝙱𝙰𝙲𝙺 𝙼𝙴𝙽𝚄 › ","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' cat /etc/passwd | grep "home" | grep "false" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
◇─────────────────────◇
    **✰ 𝙰𝙳𝙼𝙸𝙽 𝙿𝙰𝙽𝙴𝙻 𝙼𝙴𝙽𝚄 ✰**
◇─────────────────────◇
**» 𝚘𝚜     :** `{namaos.strip().replace('"','')}`
**» 𝚌𝚒𝚝𝚢 :** `{city.strip()}`
**» 𝚍𝚘𝚖𝚊𝚒𝚗 :** `{DOMAIN}`
**» 𝚒𝚙 𝚟𝚙𝚜 :** `{ipsaya.strip()}`
**» 𝚃𝙾𝚃𝙰𝙻 𝙰𝙲𝙲𝙾𝚄𝙽𝚃 𝙲𝚁𝙴𝙰𝚃𝙴𝙳:** 
**◇─────────────────────◇**
**» 🚀𝚜𝚜𝚑 𝚘𝚟𝚙𝚗   :** `{ssh.strip()}` __account__
**» 🎭𝚡𝚛𝚊𝚢 𝚟𝚖𝚎𝚜𝚜  :** `{vms.strip()}` __account__
**» 🗼𝚡𝚛𝚊𝚢 𝚟𝚕𝚎𝚜𝚜  :** `{vls.strip()}` __account__
**» 🎯𝚡𝚛𝚊𝚢 𝚝𝚛𝚘𝚓𝚊𝚗 :** `{trj.strip()}` __account__
**  🤖@JURAGAN_HC**
◇─────────────────────◇
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)


